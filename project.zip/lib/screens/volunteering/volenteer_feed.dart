// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mental_health/widgets/ActivityCard.dart';

class VolFeed extends StatefulWidget {
  const VolFeed({super.key});

  @override
  State<VolFeed> createState() => _VolFeedState();
}

class _VolFeedState extends State<VolFeed> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Volunteer Feed'),
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('activities').snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: snapshot.data!.docs.length,
                itemBuilder: (context, index) {
                  DocumentSnapshot ds = snapshot.data!.docs[index];
                  return ActivityCard(
                    title: ds['title'],
                    description: ds['description'],
                    date: ds['date&time:'],
                    url: ds['url'],
                    count: ds['count'],
                    eid: ds.id,
                    uid: ds['uid'],
                  );
                });
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}
