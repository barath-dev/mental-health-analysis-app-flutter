class OpenAIService{
  
}