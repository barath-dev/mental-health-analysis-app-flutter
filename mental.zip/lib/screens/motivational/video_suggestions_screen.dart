import 'package:flutter/material.dart';

class VideoSuggestion extends StatefulWidget {
  const VideoSuggestion({super.key});

  @override
  State<VideoSuggestion> createState() => _VideoSuggestionState();
}

class _VideoSuggestionState extends State<VideoSuggestion> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}