package com.example.mental_health

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
